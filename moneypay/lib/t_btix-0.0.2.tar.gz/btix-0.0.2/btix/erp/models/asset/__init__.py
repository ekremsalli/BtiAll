"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .faregist import LG_FAREGIST
from .fayear import LG_FAYEAR