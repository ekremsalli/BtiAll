"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .contact import LG_CONTACTS
from .dist import LG_DISTLINE, LG_DISTTEMP
from .lnopasgn import LG_LNOPASGN
from .location import LG_LOCATION
from .opertion import LG_OPERTION, LG_OPRTREQ, LG_OPATTASG
from .people import LG_ACTPEPL
from .route import LG_ROUTETRS, LG_ROUTE
from .salesman import LG_SLSMAN, LG_SLSCLREL
from .target import LG_TARGETS
from .toolreq import LG_TOOLREQ
from .earchivedet import LG_EARCHIVEDET
