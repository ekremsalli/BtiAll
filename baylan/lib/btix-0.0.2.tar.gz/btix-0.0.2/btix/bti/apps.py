"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from django.apps import AppConfig


class BtiConfig(AppConfig):
    name = 'bti'
