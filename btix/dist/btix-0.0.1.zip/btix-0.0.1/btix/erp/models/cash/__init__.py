"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .card import LG_KSCARD
from .daily import LG_CSHTOTS
from .slip import LG_KSLINES