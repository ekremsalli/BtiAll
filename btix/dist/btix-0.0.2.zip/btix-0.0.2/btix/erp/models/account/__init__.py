"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .account import LG_EMUHACC
from .code import LG_ACCCODES, LG_CRDACREF
from .fiche import LG_EMFICHE
from .log import LG_LOGREP
from .montly import LG_EMUHTOT
from .slip import LG_EMFLINE
from .tax import LG_ADDTAX, LG_ADDTAXLINE