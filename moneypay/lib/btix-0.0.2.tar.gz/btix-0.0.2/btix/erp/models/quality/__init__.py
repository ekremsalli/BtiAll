"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .assign import LG_QASGN
from .check import LG_QCLVAL
from .detail import LG_SLQCASGN
from .qset import LG_QCSET
from .slip import LG_QCSLINE