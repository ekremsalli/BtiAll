"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .fiche import LG_STFICHE
from .invoice import LG_INVOICE
from .montly import LG_SRVTOT
from .orfiche import LG_ORFICHE
from .orslip import LG_ORFLINE
from .producer import LG_PRODUCER
from .slip import LG_STLINE
from .summary import LG_SRVNUMS