"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .card import LG_CLCARD
from .fiche import LG_CLFICHE
from .intel import LG_CLINTEL
from .montly import LG_CLTOTFIL
from .risk import LG_CLRNUMS
from .slip import LG_CLFLINE