import os
import django.db.models.options as options
import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    },
    'defaultx': {
        'ENGINE': 'mssql',
        'NAME': 'rnd_test',
        'USER': 'sa',
        'PASSWORD': 'Emr12345!!',
        'HOST': '127.0.0.1',
        'PORT': '1433',
        'OPTIONS': {
            'driver': 'ODBC Driver 17 for SQL Server'
        },
        'TEST': {
            'NAME': ''
        }
    },
    'erp': {
        'ENGINE': 'mssql',
        'NAME': 'KD_2020',
        'USER': 'sa',
        'PASSWORD': 'Emr12345!!',
        'HOST': '127.0.0.1',
        'PORT': '1433',
        'OPTIONS': {
            'driver': 'ODBC Driver 17 for SQL Server'
        }
    },
    'system': {
        'ENGINE': 'mssql',
        'NAME': 'KD_TIGER',
        'USER': 'sa',
        'PASSWORD': 'Emr12345!!',
        'HOST': '127.0.0.1',
        'PORT': '1433',
        'OPTIONS': {
            'driver': 'ODBC Driver 17 for SQL Server'
        }
    }
}