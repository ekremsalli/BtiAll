"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

import zeep
from zeep.plugins import HistoryPlugin


class Elogo:
    wsdl = 'https://pb.elogo.com.tr/PostBoxService.svc?singlewsdl'
    def __init__(self, username, pwd):
        self.username = username
        self.pwd = pwd
        self.history = HistoryPlugin()

        self.client = zeep.Client(wsdl=self.wsdl)
        self.logged = False
        self.sid = None

    def login(self):
        resp = self.client.service.Login(login={
            'passWord': self.pwd,
            'userName': self.username
        })
        if resp and resp['LoginResult']:
            self.sid = resp['sessionID']
            self.logged = True
        else:
            self.sid = None
            self.logged = False

    def validate_gib(self, vkn):
        if self.logged:
            checker = self.client.service.GetValidateGIBUser(
                sessionID=self.sid,
                paramList=[f'VKN={vkn}']
            )
            if checker and (checker['resultCode'] == 1 and
                checker['errorCode'] == 0):
                resp = checker['outputList']['string']
                return {r.split('=', 1)[0]: r.split('=', 1)[1] for r in resp}
        return None
