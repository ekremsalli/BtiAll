"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .card import LG_CSCARD
from .payroll import LG_CSROLL
from .slip import LG_CSTRANS