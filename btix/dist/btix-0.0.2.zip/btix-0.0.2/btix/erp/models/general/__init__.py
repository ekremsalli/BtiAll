"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .document import LG_FOLDER
from .employee import LG_EMGRPASS, LG_EMPGROUP, LG_EMPLOYEE
from .engineering import LG_ENGCLINE
from .firmdoc import LG_FIRMDOC
from .laborreq import LG_LABORREQ
from .language import LG_LNGEXCSETS
from .period import LG_TRANSAC
from .prdcost import LG_PRDCOST
from .ship import LG_SHIPINFO
from .trigger import LG_TRGPAR
from .ebook import LG_EBOOKDETAILDOC
from .project import LG_PROJECT
