"""
 Tüm hakları BTI Bilişim Danışmanlık ve Yazılım Şirketi adına saklıdır.
 
"""

from .condition import LG_ASCOND
from .decard import LG_DECARDS
from .demand import LG_DEMANDFICHE
from .demand import LG_DEMANDLINE
from .demand import LG_DEMANDPEGGING
from .emcenter import LG_EMCENTER
from .paylines import LG_PAYLINES
from .payplans import LG_PAYPLANS
from .prcard import LG_PRCARDS
from .price import LG_PRCLIST
from .slip import LG_PAYTRANS
from .specodes import LG_SPECODES
from .srvcard import LG_SRVCARD
